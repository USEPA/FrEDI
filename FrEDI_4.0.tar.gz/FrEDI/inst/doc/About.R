## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.path = "/man/figures/",
  out.width = "100%",
  fig.align="center"
)

## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----out.width = "70%", echo=FALSE--------------------------------------------
knitr::include_graphics("../man/figures/FrEDI.png")

