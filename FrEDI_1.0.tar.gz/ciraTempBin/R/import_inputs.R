#' Import custom scenarios for temperature binning from CSV files
#'
#' @description
#' This function enables users to import data on custom scenarios for use with temperature binning. Users specify path names to CSV files containing temperature, global mean sea level rise (GMSL), gross domestic product (GDP), and population scenarios. `import_inputs()` reads in and format any specified files as data frames and returns a list of dataframes for imported scenarios.
#'
#' @param tempfile A character string indicating the location of a CSV file containing a custom temperature scenario (first column contains years in the interval 2010 to 2090; second column contains temperatures, in degrees Celsius, above the baseline).
#' @param slrfile A character string indicating the location of a CSV file containing a custom sea level rise scenario (first column contains years in the interval 2010 to 2090; second column contains values for global mean sea level rise (GMSL), in centimeters, above the baseline scenario).
#' @param popfile A character string indicating the location of a CSV file containing a custom population scenario for NCA regions. The first column contains years in the interval 2010 to 2090. The number of additional columns, column names, and column contents depend on the population format set by `popform`. For more details, see `popfile`.
#' @param gdpfile A character string indicating the location of a CSV file containing a custom scenario for gross domestic product (GDP) (first column contains years in the interval 2010 to 2090; second column contains values for GDP, in total 2015$).
#' @param temptype A character string indicating whether the temperature values in the temperature input file (specified by `tempfile` represent global temperature change (`temptype= "global"`) or temperature change for the contiguous U.S. (`temptype="conus"`) in degrees Celsius. By default, the model assumes temperatures are CONUS temperatures (i.e., `default="conus"`).
#' @param popform A character string indicating whether the populations in the population input file specified by `popfile` are spread across multiple columns (i.e., `popform="wide"`) or are combined in a single column (i.e., `popform="long"`). By default, the model assumes `popform="wide"`. For both formats (`popform="wide"` or `popform="long"`), the first column contains values for the associated value year. If `popform="wide"` (default), the second through eighth columns of `popfile ` must contain population values for each NCA region, with the associated NCA region as the column name. If `popform="long"`, the second column must contain NCA region names and the third column must contain values for the associated region population.
#'
#' @details
#' This function enables users to import data on custom scenarios for use with temperature binning. Users specify path names to CSV files containing temperature, global mean sea level rise (GMSL), population, and gross domestic product (GDP) scenarios (`tempfile`, `slrfile`, `gdpfile`, and `popfile`, respectively). `import_inputs()` reads in and formats any specified files as data frames and returns a list of dataframes for imported scenarios. Users can specify whether the temperature input is for the contiguous U.S. (CONUS) or global using `temptype` and specify the format of the population scenario using `popform`. Users can specify whether the temperature input is for the contiguous U.S. (CONUS) or global using `temptype` and specify the format of the population scenario using `popform`.
#'
#' Values for input scenarios must be within reasonable ranges. Temperatures must be in degrees Celsius and values must be greater than or equal to zero and less than or equal to 10 degrees of warming. Values for GLMSL must be in centimeters (cm) and values must be greater than or equal to zero and less than or equal to 250 cm. Population and GDP values must be greater than or equal to zero. If a user inputs a custom scenario with values outside the allowable ranges, `import_inputs()` will not import that scenario and will instead stop and return an error message.
#' `import_inputs()` drops missing values . The temperature-binning function `tempBin()` linearly interpolates missing values between available data points. For more information, see [ciraTempBin::tempBin()].
#'
#' If the temperature type is specified as global (`temptype="global"`), `import_inputs()` converts input global temperatures in degrees Celsius from the 1986-2005 baseline (`temp_global`, below) to CONUS temperatures in degrees Celsius from the same baseline (`temp_conus`, below). For more information, see [ciraTempBin::convertTemps()].
#'
#' If the population input is spread across multiple columns (i.e., `popform="wide"`), columns must be named according to the NCA regions. If the population input is in the long format, the region value must be in the second column.  The NCA region names for population inputs must be in the following character vector: `c("Midwest", "Northeast", "Northern.Plains", "Northwest", "Southeast", "Southern.Plains", "Southwest")`. All regions must be present in the population input file.
#'
#' `import_inputs()` outputs a list of dataframes that can be passed to the main temperature- and SLR-binning function `tempBin()`  using the `inputList` argument. For example, specify `tempBin(inputsList=x)` to generate impacts for a custom scenario `x` (where `x` is a list of dataframes such as that output from `import_inputs()`) (see [ciraTempBin::tempBin()]).
#'
#' All inputs to `import_inputs()` are optional. If the user does not specify a file path for `tempfile`, `slrfile`, `gdpfile`, or `popfile` (or if there is an error reading in inputs from those file paths), `import_inputs()` outputs a list with a `NULL` value for the associated list element. When the resulting list is passed as an argument to the temperature- and SLR-binning, `tempBin()` defaults back to the default scenarios for any list elements that are `NULL` or missing. In other words, running `tempBin(inputsList=list())` returns the same outputs as running `tempBin()` (see [ciraTempBin::tempBin()]).
#'
#'
#' @return
#' `import_inputs()` returns a list of named elements containing dataframes with custom scenarios for temperature, GMSL, GDP, and regional population, respectively:
#'
#' \tabular{ll}{
#' \strong{List Index} \tab \strong{Description} \cr
#' `tempInput` \tab Dataframe containing a custom temperature scenario imported from the CSV file specified by `tempfile`, with missing values removed. `tempInput` has two columns with names `c("year", "temp_C")` containing the year and CONUS temperatures in degrees Celsius, respectively. \cr
#' `slrInput` \tab Dataframe containing a custom GMSL scenario imported from the CSV file specified by `slrfile`, with missing values removed. `slrInput` has two columns with names `c("year", "slr_cm")` containing the year and global mean sea level rise (GMSL) in centimeters, respectively. \cr
#' `gdpInput` \tab Dataframe containing a custom GDP scenario imported from the CSV file specified by `gdpfile`, with missing values removed. `gdpInput` has two columns with names `c("year", "gdp_usd")` containing the year and the U.S. national GDP in 2015$, respectively. \cr
#' `popInput` \tab Dataframe containing a custom temperature scenario imported from the CSV file specified by `popfile`, with missing values removed. `popInput` has and three columns with names `c("year", "region", "reg_pop")` containing the year, the NCA region name, and the NCA region population, respectively. \cr
#' }
#'
#'
#' @examples
#' ### Path to example scenarios
#' scenariosPath <- system.file(package="ciraTempBin") %>% file.path("extdata","scenarios")
#' ### View example scenario names
#' scenariosPath %>% list.files
#' ### Temperature Scenario File Name
#' tempInputFile <- scenariosPath %>% file.path("GCAM_scenario.csv")
#' ### SLR Scenario File Name
#' slrInputFile  <- scenariosPath %>% file.path("slr_from_gcam.csv")
#' ### Population Scenario File Name
#' popInputFile  <- scenariosPath %>% file.path("pop_scenario.csv")
#' ### Import inputs
#' example_inputsList <- import_inputs(
#'   tempfile = tempInputFile,
#'   slrfile  = slrInputFile,
#'   popfile  = popInputFile
#' )
#'
#' @references Environmental Protection Agency (EPA). 2021. Technical Documentation for the Temperature Binning Framework. Technical Report EPA 430-R-21-004, EPA, Washington, DC. Available at https://epa.gov/cira/tempbinning
#'
#'
#' @export
#' @md
#'
###### import_inputs ######
### Created 2021.02.08. Last updated 2021.02.08
### This function imports data from user-specified file names.
import_inputs <- function(
  tempfile = NULL, ### File path of CSV with temperature inputs
  slrfile  = NULL,
  popfile  = NULL,
  gdpfile  = NULL,
  temptype = NULL, ### "global", or "conus" (default)
  popform  = NULL ### "wide" or "long" ### Previously: "gather", "spread"
){
  ###### Defaults ######
  # popform_default  <- "spread"
  popform_default  <- "wide"
  popform  <- ifelse(is.null(popform), popform_default, popform)
  if(!(popform=="wide")){
    message("User specified `popform='", popform, "'`...",
            "Population inputs will be gathered by region.")
  }
  ### Rename to gather and spread
  popform <- ifelse(popform == "wide", "spread", "gather")

  temptype_default <- "conus"
  temptype <- ifelse(is.null(temptype), temptype_default, temptype)
  conus    <- (temptype == temptype_default)
  if(!(conus)){
    message("User specified `temptype='global'`...",
            "Global temperatures will be converted to CONUS temperatures.")
  }

  ###### Initialize Inputs List ######
  ### Get input scenario info: co_inputScenarioInfo
  name_dfScenarioInfo <- "co_inputScenarioInfo"
  assign(name_dfScenarioInfo, rDataList[[name_dfScenarioInfo]])
  input_names_vector  <- co_inputScenarioInfo$inputName
  num_inputNames      <- co_inputScenarioInfo %>% nrow

  ###### Initialize Results List ######
  inputsList <- list()

  ###### Iterate Over Inputs List ######
  for(i in 1:num_inputNames){
    ###### Input Info ######
    inputInfo_i <- co_inputScenarioInfo[i,]

    ### Input name and label
    input_i     <- inputInfo_i$inputName %>% unique
    msgName_i   <- inputInfo_i$inputType %>% unique
    ### Input argument and tempBin argument
    inputArg_i  <- inputInfo_i$importArgName %>% unique
    inputName_i <- inputInfo_i$tempBinListName %>% unique
    ### Min and Max Values
    min_i       <- inputInfo_i$inputMin %>% unique
    max_i       <- inputInfo_i$inputMax %>% unique
    ###### Column Info ######
    region_i    <- inputInfo_i$region %>% unique
    valueCol_i  <- inputInfo_i$valueCol %>% unique
    ### Initialize column names
    numCols_i   <- colNames_i <- c("year", valueCol_i)
    ### Add region column
    if(region_i == 1){
      colNames_i  <- c(colNames_i[1], "region", colNames_i[2])
    }

    ###### Initialize Results List Element ######
    ### Initialize input in list
    inputsList[[inputName_i]] <- NULL

    ###### Parse File ######
    ### Parse inputArg_i and add to the list, then check if it is null
    inputFile_i  <- parse(text=inputArg_i) %>% eval
    isNullFile_i <- inputFile_i %>% is.null
    # list_i[["inputFile"]] <- inputFile_i
    # isNullFile_i <- list_i[["inputFile"]] %>% is.null

    ###### Format Dataframe ######
    if(!isNullFile_i){
      message( "\n", "User supplied ", msgName_i, " input. ", "Importing data from ", inputFile_i, "...")
      ### Try to import the file
      fileInput_i   <- inputFile_i %>% fun_tryInput
      fileStatus_i  <- fileInput_i[["fileStatus"]]

      ### Initialize list value
      df_input_i   <- fileInput_i[["fileInput"]]

      ######## For loaded data ######
      ### If the load is a success, add results to the input list
      if(fileStatus_i=="loaded"){
        message("\t", "Formatting inputs...")
        ###### Gather population inputs ######
        if(input_i=="pop" & popform=="spread"){
          names(df_input_i)[1] <- colNames_i[1]
          df_input_i <- df_input_i %>% gather(key = "region", value="reg_pop", -year)
        }

        ###### Standardize All Columns ######
        ### Rename Inputs and Convert all columns to numeric
        ### Rename Inputs and Convert all columns to numeric
        df_input_i  <- df_input_i %>%
          rename_inputs(colNames_i) %>%
          mutate_all(as.character) %>%
          mutate_at(vars(all_of(numCols_i)), as.numeric)

        ###### Convert Global Temps to CONUS ######
        if((input_i=="temp") & (!conus)){
          df_input_i <- df_input_i %>% mutate(temp_C = temp_C %>% convertTemps(from="conus"))
        }

        ###### Check Input ######
        message("\t", "Checking input values...", "\n")
        ### Values
        values_i <- df_input_i[,valueCol_i]
        ### Substitute NULL for missing values for min and max
        if(is.na(min_i)) min_i <- NULL; if(is.na(max_i)) max_i <- NULL
        ### Check the status
        flag_i <- values_i %>% check_inputs(xmin = min_i, xmax = max_i)
        ### Add the status to the list
        # flagList[[inputName_i]] <- flag_i
        ### Return and message the user if there is a flag:
        flagStatus_i <- flag_i$flagged
        flagRows_i   <- flag_i$rows
        ### If flag, message user and return flagStatus_i
        if(flagStatus_i){
          ### Message labels
          numrows_i    <- flagRows_i %>% length
          years_i      <- df_input_i$year[flagRows_i]; yearsLabel_i <- paste(years_i, collapse=",")
          rangeLabel_i <- paste0("c(", min_i , ",", max_i, ")")
          ### Create message and message user
          msg1_i       <- "Error in importing inputs for" %>% paste(msgName_i) %>% paste0(":")
          msg2_i       <- inputName_i %>% paste("has", numrows_i,  "values outside of defined range", rangeLabel_i)
          msg3_i       <- "Please correct values" %>% paste(msgName_i, "values for years", yearsLabel_i)

          message(msg1_i); message("\t", msg2_i); message("\t", msg3_i, "...", "\n"); message("Exiting...")
          ### Return list with error and flagged rows
          returnList <- list(
            error_msg    = paste0("Error in ", inputName_i, ". Values outside range."),
            flagged_rows = flagRows_i
            )

          ### Return list and not an inputs list if an error occurred
          return(returnList)
        } ### End if flagged

        ###### Update Results List Element ######
        ### Add results to the file
        inputsList[[inputName_i]] <- df_input_i
        
        message("\n", "Finished.")
      } ### End if status == loaded
    } ### End if !isNullFile
  }  ### End iterate on i

  ###### Return input list ######
  return(inputsList)
}

