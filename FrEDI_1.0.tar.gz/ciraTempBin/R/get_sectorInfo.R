###### get_sectorInfo ######
### Created 2021.02.11. Updated with new GMSL calculation method 2021.06.02.
#' Convert global temperature change to global mean sea level rise (GMSL) in centimeters
#'
#' @description
#' This helper function returns a character vector of sector names (default) *or* a dataframe of sectors with related information (e.g., associated adaptations, impact types, etc.), which the user can supply to the [ciraTempBin::tempBin()] `sectorList` argument.
#'
#' @param description = FALSE. Logical value indicating whether to include information about each sector. Returns a dataframe if `description=TRUE` and returns a character vector of sector names if `description=FALSE` (default).
#' @param gcmOnly = FALSE. Logical value indicating whether to return only sectors with climate impacts modeled using global climate model (GCM) results.
#' @param slrOnly = FALSE. Logical value indicating whether to return only sectors with climate impacts modeled using sea level rise (SLR) scenarios.
#' 
#' @details 
#' This helper function returns a character vector of sector names (default) *or* a dataframe of sectors with related information if `description=TRUE` (e.g., associated adaptations, impact types, etc.), which the user can supply to the [ciraTempBin::tempBin()] `sectorList` argument. 
#' 
#' If `description=FALSE` (default), returns a character vector of sector names. 
#' If `description=TRUE`, returns a dataframe containing the names of sectors available for temperature binning in one column, with information about the sector model type, adaptations, impact years, and impact types in the remaining columns.
#' 
#' Users can specify whether to return only GCM sectors *or* SLR sectors by setting `gcmOnly=TRUE` or `slrOnly=TRUE`, respectively. `get_sectorInfo` will return the sectors in the form specified by `description` (see above).
#' 
#' @return
#' 
#' * If `description=FALSE` (default), outputs a character vector containing the names of sectors available for temperature binning. 
#' * If `description=TRUE`, outputs a dataframe containing the names of sectors available for temperature binning in one column, with information about the sector model type, adaptations, impact years, and impact types in the remaining columns.
#'
#' @examples
#' get_sectorInfo()
#' get_sectorInfo(description=T, gcmOnly=T)
#'
#' @references Environmental Protection Agency (EPA). 2021. Technical Documentation for the Temperature Binning Framework. Technical Report EPA 430-R-21-004, EPA, Washington, DC. Available at https://epa.gov/cira/tempbinning
#'
#' @export
#' @md
#'
### 
###  
get_sectorInfo <- function(
  description=F, 
  gcmOnly=F,
  slrOnly=F
  ){
  if(is.null(description)){description<-F}
  if(is.null(gcmOnly    )){gcmOnly    <-F}
  if(is.null(slrOnly    )){slrOnly    <-F}
  # co_sectorsRef$sector_label
  assign("co_sectorsRef", rDataList[["co_sectors"]])
  
  co_sectorsRef <- co_sectorsRef %>% 
    select(-c("sector_id")) %>%
    rename(sector     = sector_label) %>%
    rename(model_type = modelType) %>%
    mutate(model_type = model_type %>% toupper)
  
  gcm_string <- "GCM"
  if(gcmOnly){
    co_sectorsRef <- co_sectorsRef %>% filter(model_type==gcm_string)
  } else if(slrOnly){
    co_sectorsRef <- co_sectorsRef %>% filter(model_type!=gcm_string)
  }
  
  ### If not description, return names only
  if(!description){
    return_obj <- co_sectorsRef$sector
  } else{
    return_obj <- co_sectorsRef %>% as.data.frame
  }
  
  return(return_obj)
}